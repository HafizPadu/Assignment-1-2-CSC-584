<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Business Card - ${fullName}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .business-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 800px;
            width: 100%;
            overflow: hidden;
            animation: slideUp 0.6s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .avatar {
            width: 100px;
            height: 100px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 48px;
            border: 3px solid white;
        }

        .card-header h1 {
            font-size: 28px;
            margin-bottom: 5px;
        }

        .card-body {
            padding: 30px;
        }

        .info-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .info-item {
            padding: 15px;
            background: #f8f9fa;
            border-radius: 12px;
            transition: transform 0.3s;
        }

        .info-item:hover {
            transform: translateX(5px);
        }

        .info-label {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #667eea;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .info-value {
            font-size: 16px;
            color: #333;
            font-weight: 500;
        }

        .bio-section {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            padding: 20px;
            border-radius: 12px;
        }

        .bio-section h3 {
            color: #764ba2;
            margin-bottom: 12px;
        }

        .bio-text {
            color: #555;
            line-height: 1.6;
        }

        .card-footer {
            background: #f8f9fa;
            padding: 15px;
            text-align: center;
            border-top: 1px solid #e0e0e0;
        }

        .btn-back {
            display: inline-block;
            padding: 10px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 25px;
            transition: all 0.3s;
        }

        .btn-back:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
    </style>
</head>
<body>
    <div class="business-card">
        <div class="card-header">
            <div class="avatar">👤</div>
            <h1>${fullName}</h1>
            <div style="opacity: 0.9;">${academicProgram}</div>
        </div>
        
        <div class="card-body">
            <div class="info-section">
                <div class="info-item">
                    <div class="info-label">🎓 Student ID</div>
                    <div class="info-value">${studentId}</div>
                </div>
                
                <div class="info-item">
                    <div class="info-label">📧 Email</div>
                    <div class="info-value">${email}</div>
                </div>
                
                <div class="info-item">
                    <div class="info-label">🎯 Hobbies</div>
                    <div class="info-value">${hobbies}</div>
                </div>
            </div>
            
            <div class="bio-section">
                <h3>📝 Professional Bio</h3>
                <div class="bio-text">${bio}</div>
            </div>
        </div>
        
        <div class="card-footer">
            <a href="index.html" class="btn-back">← Create Another Card</a>
        </div>
    </div>
</body>
</html>