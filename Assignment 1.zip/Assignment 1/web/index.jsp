<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Digital Business Card Creator</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 100%;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 {
            text-align: center;
            color: #667eea;
            margin-bottom: 10px;
        }
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        .required:after {
            content: " *";
            color: red;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            opacity: 0.9;
        }
        .error {
            background: #fee;
            color: #c00;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 3px solid #c00;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>✨ Digital Business Card ✨</h1>
        <div class="subtitle">Create your professional profile</div>
        
        <% 
            String error = (String) request.getAttribute("error");
            if (error != null) {
        %>
            <div class="error"><%= error %></div>
        <% } %>
        
        <form action="ProfileController" method="POST">
            <div class="form-group">
                <label class="required">Full Name</label>
                <input type="text" name="fullName" required>
            </div>
            
            <div class="form-group">
                <label class="required">Student ID</label>
                <input type="text" name="studentId" required>
            </div>
            
            <div class="form-group">
                <label class="required">Academic Program</label>
                <input type="text" name="academicProgram" required>
            </div>
            
            <div class="form-group">
                <label class="required">Email</label>
                <input type="email" name="email" required>
            </div>
            
            <div class="form-group">
                <label>Hobbies</label>
                <input type="text" name="hobbies">
            </div>
            
            <div class="form-group">
                <label>Professional Bio</label>
                <textarea name="bio"></textarea>
            </div>
            
            <button type="submit">Create Card →</button>
        </form>
    </div>
</body>
</html>