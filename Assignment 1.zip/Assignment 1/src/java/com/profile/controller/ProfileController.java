package com.profile.controller;

import java.io.IOException;
import java.util.regex.Pattern;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ProfileController")
public class ProfileController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@(.+)$";
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Get form data
        String fullName = request.getParameter("fullName");
        String studentId = request.getParameter("studentId");
        String academicProgram = request.getParameter("academicProgram");
        String email = request.getParameter("email");
        String hobbies = request.getParameter("hobbies");
        String bio = request.getParameter("bio");
        
        // Validation
        boolean isValid = true;
        StringBuilder errorMessage = new StringBuilder();
        
        if (fullName == null || fullName.trim().isEmpty()) {
            isValid = false;
            errorMessage.append("Full Name is required.<br>");
        }
        
        if (studentId == null || studentId.trim().isEmpty()) {
            isValid = false;
            errorMessage.append("Student ID is required.<br>");
        }
        
        if (academicProgram == null || academicProgram.trim().isEmpty()) {
            isValid = false;
            errorMessage.append("Academic Program is required.<br>");
        }
        
        if (email == null || email.trim().isEmpty()) {
            isValid = false;
            errorMessage.append("Email is required.<br>");
        } else if (!Pattern.matches(EMAIL_REGEX, email)) {
            isValid = false;
            errorMessage.append("Invalid email format.<br>");
        }
        
        // If validation fails, return to form
        if (!isValid) {
            request.setAttribute("error", errorMessage.toString());
            request.getRequestDispatcher("index.html").forward(request, response);
            return;
        }
        
        // Set attributes for JSP using request.getAttribute()
        request.setAttribute("fullName", fullName.trim());
        request.setAttribute("studentId", studentId.trim());
        request.setAttribute("academicProgram", academicProgram.trim());
        request.setAttribute("email", email.trim());
        request.setAttribute("hobbies", (hobbies != null && !hobbies.trim().isEmpty()) ? hobbies.trim() : "Not specified");
        request.setAttribute("bio", (bio != null && !bio.trim().isEmpty()) ? bio.trim() : "No bio provided.");
        
        // Forward to display.jsp using request.getRequestDispatcher()
        request.getRequestDispatcher("display.jsp").forward(request, response);
    }
}